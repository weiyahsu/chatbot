# 核心肌群｜RAG 練習資料集

整理日期：2026-10-29（台灣時間）

包含 35 份 UTF-8 繁體中文 TXT。每份有標題、來源單位、授權、來源網址、短篇教學改寫摘要，以及一個檢索練習問題。格式對齊 `/home/user/下載/rag-data.zip` 的分檔方式。

重要：本資料集不是開放教材的逐段全文。全文摘錄不適合這份教學格式，這裡只保留可回溯來源的短摘要，方便測試 RAG。

建議教學：
1. 先把各 TXT 視為一份 document，按段落或固定 token 數切塊。
2. 計算 embeddings，檢索 top-k 後要求模型只根據取得段落回答，並列出文件名稱及來源 URL。
3. 讓學生試問 `問題集.csv`，比較 top-k = 1 與 3，以及純 LLM 與 RAG。
4. 測試超出知識庫的問題，要求回答「目前文件沒有足夠資訊」。個人影像、訓練處方，以及未收錄的商業教科書，都應拒絕臆測。

授權：
- Oregon State University《Anatomy & Physiology》第 1 版，Lindsay M. Biga 等與 OpenStax，CC BY-SA 4.0。https://open.oregonstate.education/anatomy/
- Okanagan College / LibreTexts《HKIN 110: Human Anatomy I for Kinesiology》，CC BY-NC-SA 4.0。整包一起散布時，請依 CC BY-NC-SA 4.0 處理：須署名、不可商用、改作須相同方式分享。

署名時請保留各檔的來源單位、授權與來源網址。本摘要不能代替個人醫療或復健建議。

圖片：
各 TXT 的【圖片】指向 `images/`。解剖圖來自 Henry Gray《Anatomy of the Human Body》（1918）圖版，經 Wikimedia Commons 取得，為公有領域，不是 Oregon State 或 LibreTexts 教材裡的圖。`08_trunk-movements.svg` 是本資料集的動作方向示意，不是標本。圖上的拉丁文或舊英文標籤保持原樣，中文圖說寫在 TXT 裡。
